<?php
defined('_JEXEC') or die('Restricted access'); // no direct access
?>
<a href="<?php echo $link ?>" class="rss-tag-icon" title="<?php echo $params->get('text'); ?>">
	<?php echo JHTML::_('image.site', 'livemarks.png', '/images/M_images/', NULL, NULL, 'feed-image'); ?></a>