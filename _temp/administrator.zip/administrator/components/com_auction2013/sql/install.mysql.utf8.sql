-- $Id: install.mysql.utf8.sql date

-- DROP TABLE IF EXISTS `#__auction2013`;

-- CREATE TABLE `#__auction2013` (
--  `id` int(11) NOT NULL auto_increment,
--  `field1_name` varchar(25) NOT NULL,
--   PRIMARY KEY  (`id`)
-- ) ENGINE=MyISAM AUTO_INCREMENT=0 DEFAULT CHARSET=utf8;

