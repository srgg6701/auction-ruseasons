-- $Id: uninstall.mysql.utf8.sql date

-- DROP TABLE IF EXISTS `#__auction2013`;

